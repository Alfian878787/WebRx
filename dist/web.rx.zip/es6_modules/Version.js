export const version = '1.4.4';
//# sourceMappingURL=Version.js.map