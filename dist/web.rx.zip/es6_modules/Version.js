export const version = '1.5.0';
//# sourceMappingURL=Version.js.map