/// <reference path="../Interfaces.d.ts" />
export declare var injector: wx.IInjector;
