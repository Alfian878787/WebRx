/// <reference path="../Interfaces.d.ts" />
/**
* Determines if target is an instance of a IObservableList
* @param {any} target The object to test
*/
export declare function isList(target: any): boolean;
