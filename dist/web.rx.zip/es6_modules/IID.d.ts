export default class IID {
    static IDisposable: string;
    static IObservableProperty: string;
    static IObservableReadOnlyProperty: string;
    static IObservableList: string;
    static ICommand: string;
    static IHandleObservableErrors: string;
}
